console.warn('Load Time ⏳');
console.time();
console.timeLog();
console.timeEnd();